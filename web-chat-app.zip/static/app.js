const messagesEl=document.getElementById('messages');
const form=document.getElementById('sendForm');
const messageInput=document.getElementById('messageInput');
const usernameInput=document.getElementById('username');

async function fetchMessages(){
  const r=await fetch('/messages');
  const d=await r.json();
  messagesEl.innerHTML='';
  d.messages.forEach(m=>{
    const div=document.createElement('div');
    div.textContent=`${m.username}: ${m.message}`;
    messagesEl.appendChild(div);
  });
  messagesEl.scrollTop=messagesEl.scrollHeight;
}

form.addEventListener('submit',async e=>{
  e.preventDefault();
  const msg=messageInput.value.trim();
  if(!msg) return;
  await fetch('/send',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({username:usernameInput.value,message:msg})});
  messageInput.value='';
  fetchMessages();
});

setInterval(fetchMessages,1000);
fetchMessages();
