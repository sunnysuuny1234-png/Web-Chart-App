from flask import Flask, jsonify, request, render_template
import json
import threading
from datetime import datetime
import os

app = Flask(__name__)
lock = threading.Lock()
CHAT_FILE = os.path.join(os.path.dirname(__file__), 'chat.json')

if not os.path.exists(CHAT_FILE):
    with open(CHAT_FILE, 'w', encoding='utf-8') as f:
        json.dump({"messages": []}, f, ensure_ascii=False, indent=2)

def read_messages():
    with lock:
        with open(CHAT_FILE, 'r', encoding='utf-8') as f:
            data = json.load(f)
    return data.get('messages', [])

def write_messages(messages):
    with lock:
        with open(CHAT_FILE, 'w', encoding='utf-8') as f:
            json.dump({"messages": messages}, f, ensure_ascii=False, indent=2)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/messages', methods=['GET'])
def get_messages():
    return jsonify({"messages": read_messages()})

@app.route('/send', methods=['POST'])
def send_message():
    data = request.get_json()
    if not data:
        return jsonify({"error": "Invalid JSON"}), 400

    username = data.get('username', 'Anonymous').strip() or 'Anonymous'
    text = data.get('message', '').strip()
    if not text:
        return jsonify({"error": "Message empty"}), 400

    message = {
        "username": username,
        "message": text,
        "timestamp": datetime.utcnow().isoformat()+'Z'
    }

    messages = read_messages()
    messages.append(message)
    if len(messages) > 1000:
        messages = messages[-1000:]
    write_messages(messages)

    return jsonify({"status": "ok"}), 201

@app.route('/messages', methods=['DELETE'])
def clear_messages():
    write_messages([])
    return jsonify({"status": "cleared"})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
